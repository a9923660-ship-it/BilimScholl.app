// Copy entries into the `books` array inside index.html. Use relative paths for files hosted with the site.
// Example:
// const books = [
//   { id: "math-1", title: "Математика", grade: 1, subject: "Математика", file: "files/1/matematika.pdf", description: "Учебник для 1 класса" },
//   { id: "kyrgyz-1", title: "Кыргыз тили", grade: 1, subject: "Кыргыз тили", file: "files/1/kyrgyz-tili.pdf", description: "Окуу китеби" }
// ];
